import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ChartModule } from 'angular2-highcharts';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BarComponent } from './bar/bar.component';
import { AreabarComponent } from './areabar/areabar.component';

import { HttpClientModule } from '@angular/common/http';

//import {chart} from 'highcharts';
import * as Highcharts from 'highcharts';
import * as HighchartsMore from 'highcharts-more';
HighchartsMore(Highcharts);

//import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';

declare var require:any;

@NgModule({
  declarations: [
    AppComponent,
    BarComponent,
    AreabarComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ChartModule.forRoot(require('highcharts')),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
platformBrowserDynamic().bootstrapModule(AppModule);
