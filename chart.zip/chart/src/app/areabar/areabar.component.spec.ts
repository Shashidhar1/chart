import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AreabarComponent } from './areabar.component';

describe('AreabarComponent', () => {
  let component: AreabarComponent;
  let fixture: ComponentFixture<AreabarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AreabarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AreabarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
