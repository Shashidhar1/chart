import { Component, OnInit } from '@angular/core';

import { GraphService } from '../graph.service';

@Component({
  selector: 'app-areabar',
  templateUrl: './areabar.component.html',
  styleUrls: ['./areabar.component.css']
})
export class AreabarComponent implements OnInit {

  constructor(public _mainservice: GraphService) {}

  i:number;
  newlist: any[] = [];
  stdDev: any[] = [];
  arraylist: any;
  MedianVal:any;

  public graphSeriesdata() 
  {
    this._mainservice.getPatients()
      .subscribe(response => {
        this.arraylist = response;

            for(let i= 0, l = this.arraylist.length; i< l; i++)
            {
                let response:any =  this.arraylist[i];
                this.newlist.push([response.Time, response.Min, response.MAX]);

                this.MedianVal = this.getMedianValue(response.Min, response.MAX);

                this.stdDev.push([this.MedianVal]);
            }

            this.getGraphPlot(this.newlist,this.stdDev);
             //console.log("data==" + JSON.stringify(this.stdDev));
      }, error => {
        console.log("error:" +error);
      });

  }


  ngOnInit() {

    this.graphSeriesdata();
  }

  getMedianValue(min,max)
  { 
    //Formula to calculate the Median Value
    let value:number = ((max+min)/2);
    return value;
  }

  getGraphPlot(dataList,medianData)
  {

    console.log("data==" + JSON.stringify(dataList));
    this.optionsareabar= {
    title : {text : 'Recent AGP'},
  
    chart: {
      zoomType: 'xy',
      type: 'columnrange',
      width:800,
      height:400,
     
  },
  subtitle: {
      text: 'AGP Graphs'
  },
  
  xAxis:
        [{//Primary Xaxis
          opposite: true,
          type: 'datetime',
          tickInterval:  2 * 3600 * 1000,
          dateTimeLabelFormats: {
              day:'%I%P',
              minute:'%I%P',
              hour:'%I%P',
          },
        },
        {
          //Secondary Xaxis
          //opposite: true,
          visible: false,
          type: 'datetime',
          tickInterval:  2 * 3600 * 1000,
          dateTimeLabelFormats: {
              day:'%I%P',
              minute:'%I%P',
              hour:'%I%P',
          },
        }

       ],

yAxis: [{//Primary YAxis
    min:0,
  max:280,
  tickInterval: 50,
  // categories: [
  //           54,
  //           70,
  //           80,
  //           140,
  //           180,
  //           200,
  //           240,
  //       ],
       
  opposite:true,
    title: {
        text: 'Recent AGP'
    },

    gridLineWidth: 0,

    plotLines: [{
      color: '#cc0e22', // Color value
      dashStyle: 'ShortDot', // Style of the plot line. Default to solid
      value: 54, // Value of where the line will appear
      width: 1 // Width of the line    
    },
    {
      color: '#ffcb98', // Color value
      dashStyle: 'ShortDot', // Style of the plot line. Default to solid
      value: 70, // Value of where the line will appear
      width: 1 // Width of the line    
    },
    {
      color: '#354db4', // Color value
      dashStyle: 'ShortDot', // Style of the plot line. Default to solid
      value: 200, // Value of where the line will appear
      width: 1 // Width of the line    
    },
  
  ],
 
},
{//Secondary YAxis
  visible: false,
}
],

tooltip: {
    valueSuffix: '°C'
},

plotOptions: {
    columnrange: {
        dataLabels: {
            enabled: false,
            //format: '{y}°C'
        }
    },
    series: {
      pointWidth: 4,
      pointPadding: 0.1,
      groupPadding: 0,     
  }
},

legend: {
    enabled: false
},

credits : {
  enabled: false
},

series: [{
     name: 'AGP Graph',
     //id: 'conf-interval',
     data: dataList,
     color: '#b8b8b8',
     fillOpacity: 0.3,
     zIndex: 0,
     marker: {
     // symbol: 'diamond',
        fillColor: 'white',
        enabled: false
     }
     
},
{
  type: 'spline',
  data: medianData,
  color: '#ffffff',
  xAxis:1,
  YAxis:1,
  showInLegend: false,
  enableMouseTracking: false,
  marker: {
    symbol: 'spline',
    enabled: false,
    lineColor: '#ffffff',
    lineWidth: 5,
    radius: 1.5
  },
  dashStyle: 'shortdot',
}]
    };

  }

  optionsareabar:object;



  

}
