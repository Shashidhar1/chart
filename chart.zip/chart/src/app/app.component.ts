import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  

  constructor() {

    this.options = {
      title : {text : 'Angular chart'},
    
      chart : { type: "column",
                //zoomType : 'x'
              },

      subtitle: {
        text: 'Source: Bar Chart with percentage'
    },

  //   xAxis: {
  //     categories: [
  //         '12AM',
  //         '3AM',
  //         '6AM',
  //         '9AM',
  //         '12PM',
  //         '3PM',
  //         '6PM',
  //         '9PM',
  //         '12AM'
  //     ],
  //     crosshair: true
  // },

  // yAxis: {
  //     min: 0,
  //     title: {
  //         text: 'Rainfall (mm)'
  //     }
  // },
  yAxis : {
    min: 0,
    title: {
       text: 'Population (millions)',
       align: 'high'
    },
    labels: {
       overflow: 'justify'
    }
 },

  //Series name block alignment
  legend: {
    align: 'right',
    x: -30,
    verticalAlign: 'top',
    y: 25,
    floating: true,
   // backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
    borderColor: '#CCC',
    borderWidth: 1,
    shadow: false
  },

  tooltip: {
    pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
    shared: true
    },
    plotOptions: {
        column: {
            stacking: 'percent'
        }
    },

     credits : {
      enabled: false
    },
    
    //   series : [{ 
    //     name: 'Tokyo', 
    //    // data: [20.7,88.8,222.4,154.2,50.17,120], 
    //   //  data: [
    //   //       {
    //   //           name: "a",
    //   //           y: 100
    //   //       },
    //   //       {
    //   //           name: "b",
    //   //           y: 20
    //   //       },
    //   //       {
    //   //           name: "c",
    //   //           y: 50
    //   //       }
    //   //   ]

    // //  data: [5, 3, 4, 7, 2],   
    //   }]

    series: [{
      name: 'John',
      //data: [5]
      data : [{ y: 10}],
      marker: {
        lineWidth: 2,
        //lineColor: Highcharts.getOptions().colors[3],
        fillColor: 'white'
    }
  }, {
      name: 'Jane',
      //data: [3]
      data : [{ y: 60}],
      marker: {
        lineWidth: 2,
        //lineColor: Highcharts.getOptions().colors[3],
        fillColor: 'white'
    }
  }, {
      name: 'Joe',
      //data: [4]
      data : [{ y: 40}],
      marker: {
        lineWidth: 2,
        //lineColor: Highcharts.getOptions().colors[3],
        fillColor: 'white'
    }
  }]
    
      };

  }

 options:object;


}
